<?php userstatus();head('Ihre Radios');$settings = mysql_fetch_array(db_query("SELECT uid,exchange FROM radioearn_settings LIMIT 1"));
$artsort = (INT)$_POST['art'];$valsort = (INT)$_POST['val'];
if ($artsort <= "1"){$sortart = "station";$selecta1 = " selected";}
if ($artsort == "2"){$sortart = "ip";$selecta2 = " selected";}
if ($artsort == "3"){$sortart = "feedback";$selecta4 = " selected";}
if (($artsort == "") OR ($artsort == "4")){$sortart = "nextpayment";$selecta5 = " selected";}
if ($artsort >= "5"){$sortart = "pts";$selecta6 = " selected";}
if (($valsort == "") OR ($valsort == "1")){$sortval = "DESC";$selectv1 = " selected";}
if ($valsort >= "2"){$sortval = "ASC";$selectv2 = " selected";}
$radiotext = 'lib/texte/radio.txt';$fp = fopen ($radiotext, "r");$inhalt = fread ($fp, filesize ($radiotext));fclose ($fp);$inhalt = str_replace('\\', '', $inhalt);echo nl2br($inhalt);?>
<br /><hr><b>Wann werde ich bezahlt?</b> Jede 15 Minuten bekommen Sie <?php echo number_format($settings[1]/4,0,",",".");?> <?php echo $waehrung;?> pro Radio & IP auf das Konto. Sie können in den Buchungen Ihre Verdienste oder Fehler sehen.<hr><br /><br />
<table width="100%" border="1"><tr><td align="center"><b>Radio-Link</b></td><td align="center"><b>Genre</b></td></tr>
<?php $context = stream_context_create(array('https' => array('')));$url = "https://radioearn.com/api/radios.php";$data = file_get_contents($url, false, $context);$xml = simplexml_load_string($data);foreach($xml->Link as $key => $value){$Link = $value->Radio;$Genre = $value->Genre;echo '<tr><td align="center"><a target="_blank" href="'.$Link.'start.php?uid='.$settings[0].'&suid='.(INT)$_SESSION['uid'].'">'.$Link.'start.php?uid='.$settings[0].'&suid='.(INT)$_SESSION['uid'].'</a></td><td align="center">'.$Genre.'</td></tr>';}?>
</table><br /><br /><b>Funktioniert mit allen HTML5-Audio kompatiblen Browsern.</b> Sie können Ihren Radio-Link auch teilen, z.B. über soziale Medien etc.
<br /><br /><b>Unterstützte Länder:</b> <?php $context1 = stream_context_create(array('https' => array('')));$url1 = "https://radioearn.com/api/countries.php";$data1 = file_get_contents($url1, false, $context1);$xml1 = simplexml_load_string($data1);foreach($xml1->GEO as $key1 => $value1){$geoinf = $value1->Supported;echo $geoinf;}
foot();head("Laufende Radios (letzte 10 Min.)");$m10min = time()-610;
$howm = mysql_fetch_array(db_query("SELECT COUNT(ip) FROM radioearn_api WHERE subid='".(INT)$_SESSION['uid']."' && feedback >= '".$m10min."'"));
$daten = db_query("SELECT ip,station,nextpayment,feedback,pts,status FROM radioearn_api WHERE subid='".(INT)$_SESSION['uid']."' && feedback >= '".$m10min."' ORDER BY ".$sortart." ".$sortval."");
if ($howm[0] == "1"){$radn = "Sie nutzen derzeit 1 Radio.";}else{$radn = "Sie nutzen derzeit ".number_format($howm[0],0,",",".")." Radios.";}?><center><b><?php echo $radn;?></b>
<hr><b>Sortieren nach:</b><br /><form action="./?content=/verdienen/radio" method="post"><table border="0"><tr><td valign="top"><select name="art"><option value="1"<?php echo $selecta1;?>>Station</option><option value="2"<?php echo $selecta2;?>>IP Adresse</option><option value="3"<?php echo $selecta4;?>>Letzte Rückmeldung</option><option value="4"<?php echo $selecta5;?>>Nächste Zahlung</option><option value="5"<?php echo $selecta6;?>>Verdienst (<?php echo $waehrung;?>)</option></select></td><td valign="top"><select name="val"><option value="1"<?php echo $selectv1;?>>Hoch zuerst</option><option value="2"<?php echo $selectv2;?>>Niedrig zuerst</option></select></td><td valign="top"><input type="submit" value=">>>"></td></table></form></center><br />
<table width="100%"><tr><td align="center"><b>Status</b></td><td align="center"><b>Station</b></td><td align="center"><b>IP</b></td><td align="center"><b>Letzte Rückmeldung</b></td><td align="center"><b>Nächste Zahlung</b></td><td align="center"><b>Verdienst</b></td></tr>
<?php while ($dat = mysql_fetch_array($daten)){if ($dat[5] == 1){$icon = "<img src='images/gruen.gif'>";}else{$icon = "<img src='images/rot.gif'>";}
$i++;if ($i % 2 == 0){$row = 0;}else{$row = 1;}?><tr class="tabellenbody_<?php echo $row;?>"><td align="center"><?php echo $icon;?></td><td align="center"><?php echo $dat[1];?></td><td align="center"><?php echo $dat[0];?></td><td align="center"><?php echo date("H:i:s",$dat[3]);?></td><td align="center"><?php echo date("H:i:s",$dat[2]);?></td><td align="center"><?php echo number_format($dat[4]*$settings[1],0,",",".");?> <?php echo $waehrung;?></td></tr><?php }?></table><?php foot();?>
