<?php head('Einstellungen Radio-Addon');$settings = mysql_fetch_array(db_query("SELECT api,uid,exchange FROM radioearn_settings LIMIT 1"));
if ($_POST['data'] == 'Einstellen'){db_query("UPDATE radioearn_settings SET api='".$_POST['api']."',uid='".$_POST['uid']."',exchange='".$_POST['exchange']."'");echo "<center><b>Einstellungen aktualisiert.</b></center><hr>";}?>
<form action="" method="post"><table width="100%">
<tr><td width="50%"><b>API-URL</b></td><td width="50%"><input type="text" name="api" value="<?echo $settings[0];?>" size="60"></td></tr>
<tr><td width="50%"><b>User-ID</b></td><td width="50%"><input type="text" name="uid" value="<?echo $settings[1];?>" size="60"></td></tr>
<tr><td width="50%"><b>Umrechnung</b><br />[1 Pts = X <?php echo $waehrung;?>]</td><td width="50%"><input type="text" name="exchange" value="<?php echo $settings[2];?>" size="60"><br /><?php echo $waehrung;?></td></tr>
<tr><td width="50"></td><td width="50%"><input type="Submit" name="data" value="Einstellen"></td></tr></table><br /></form><?php foot();
$radiofile = '../lib/texte/radio.txt';if (!isset($_POST['Update'])){$_POST['Update'] = '';}if (!isset($_POST['text'])){$_POST['text'] = '';}
if ($_POST['Update'] == 'Update'){$_POST['text'] = str_replace('\\', '', $_POST['text']);$fp = fopen ($radiofile, "w");fwrite ($fp, $_POST['text']);fclose ($fp);}
$fp = fopen ($radiofile, "r");$inhalt = @fread ($fp, filesize ($radiofile));fclose ($fp);$inhalt = str_replace('\\', '', $inhalt);
head("Text über Radio-Addon (HTML möglich)");?><div align="center"><form action="" method="post">
<textarea name="text" style="width:90%; height:500px;"><?php echo $inhalt;?></textarea><br>
<input type="Submit" name="Update" value="Update"></form></div><?php foot();?>
