<?php head('Radios (letzte 10 Minuten)');$settings = mysql_fetch_array(db_query("SELECT exchange FROM radioearn_settings LIMIT 1"));
$artsort = (INT)$_POST['art'];$valsort = (INT)$_POST['val'];
if ($artsort <= "1"){$sortart = "station";$selecta1 = " selected";}
if ($artsort == "2"){$sortart = "subid";$selecta2 = " selected";}
if ($artsort == "3"){$sortart = "ip";$selecta3 = " selected";}
if ($artsort == "4"){$sortart = "feedback";$selecta4 = " selected";}
if ($artsort == "5"){$sortart = "nextpayment";$selecta5 = " selected";}
if (($artsort == "") OR ($artsort >= "6")){$sortart = "pts";$selecta6 = " selected";}
if (($valsort == "") OR ($valsort == "1")){$sortval = "DESC";$selectv1 = " selected";}
if ($valsort >= "2"){$sortval = "ASC";$selectv2 = " selected";}$m10min = time()-610;
$daten = db_query("SELECT ip,station,nextpayment,feedback,pts,status,subid FROM radioearn_api WHERE feedback >= '".$m10min."' ORDER BY ".$sortart." ".$sortval."");
$rradios = mysql_fetch_array(db_query("SELECT COUNT(ip) FROM radioearn_api WHERE feedback >= '".$m10min."' AND status='1'"));
$aradios = mysql_fetch_array(db_query("SELECT COUNT(ip) FROM radioearn_api WHERE feedback >= '".$m10min."'"));?>
<center><b>Sortieren nach:</b><br /><form action="./?content=/radio/overview" method="post"><table border="0"><tr><td valign="top"><select name="art"><option value="1"<?php echo $selecta1;?>>Station</option><option value="2"<?php echo $selecta2;?>>Mitglied</option><option value="3"<?php echo $selecta3;?>>IP Adresse</option><option value="4"<?php echo $selecta4;?>>Letzte Rückmeldung</option><option value="5"<?php echo $selecta5;?>>Nächste Zahlung</option><option value="6"<?php echo $selecta6;?>>Verdienst (<?php echo $waehrung;?>)</option></select></td><td valign="top"><select name="val"><option value="1"<?php echo $selectv1;?>>Hoch zuerst</option><option value="2"<?php echo $selectv2;?>>Niedrig zuerst</option></select></td><td valign="top"><input type="submit" value=">>>"></td></table></form>
<hr>Aktuell laufen <?php echo number_format($rradios[0],0,",",".");?> von <?php echo number_format($aradios[0],0,",",".");?> Radios.<hr></center><br />
<table width="100%"><tr><td align="center"><b>Status</b></td><td align="center"><b>Station</b></td><td align="center"><b>Mitglied</b></td><td align="center"><b>IP</b></td><td align="center"><b>Letzte Rückmeldung</b></td><td align="center"><b>Nächste Zahlung</b></td><td align="center"><b>Verdienst</b></td></tr>
<?php while ($dat = mysql_fetch_array($daten)){if ($dat[5] == 1){$icon = "<img src='images/gruen.gif'>";}else{$icon = "<img src='images/rot.gif'>";}
$nickname = mysql_fetch_array(db_query("SELECT nickname FROM ".$db_prefix."_userdaten WHERE uid='".$dat[6]."' LIMIT 1"));
$i++;if ($i % 2 == 0){$row = 0;}else{$row = 1;}?><tr class="tabellenbody_<?php echo $row;?>"><td align="center"><?php echo $icon;?></td><td align="center"><?php echo $dat[1];?></td><td align="center"><a target="_blank" href="?content=/usersystem/userbearbeiten&uid=<?echo $dat[6];?>"><?php echo '['.$dat[6].'] '.$nickname[0];?></a></td><td align="center"><?php echo $dat[0];?></td><td align="center"><?php echo date("H:i:s",$dat[3]);?></td><td align="center"><?php echo date("H:i:s",$dat[2]);?></td><td align="center"><?php echo number_format($dat[4]*$settings[0],0,",",".");?> <?php echo $waehrung;?></td></tr><?php }?></table><?foot();?>
