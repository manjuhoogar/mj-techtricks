<?php sleep(3);@set_time_limit(0);@ignore_user_abort(true);require_once ("lib/functions.lib.php");require_once ("lib/config.inc.php");db_connect();$dumptm = time()-610;$nxtpayment = time()-1100;
db_query("DELETE FROM radioearn_api WHERE feedback <= '".$dumptm."'");db_query("DELETE FROM radioearn_api WHERE nextpayment <= '".$nxtpayment."'");
$settings = mysql_fetch_array(db_query("SELECT api,exchange FROM radioearn_settings LIMIT 1"));
$context = stream_context_create(array('https' => array('')));$url = $settings[0];$data = file_get_contents($url, false, $context);$xml = simplexml_load_string($data);
foreach($xml->Listener as $key => $value){$Status = $value->Status;$Station = $value->Station;$IPE = $value->IP;$SubID = $value->SubID;$NextPayment = $value->NextPayment;$Feedback = $value->Feedback;$Pts = $value->Pts;
$pfnmin = time()+900;$capi = mysql_fetch_array(db_query("SELECT status,nextpayment FROM radioearn_api WHERE ip='".$IPE."' AND subid='".$SubID."' AND station='".$Station."' LIMIT 1"));
if ($capi[0] == ""){db_query("INSERT INTO radioearn_api (ip,subid,station,nextpayment,feedback,pts,status) VALUES ('".$IPE."','".$SubID."','".$Station."','".$pfnmin."','".$Feedback."','".$Pts."','".$Status."')");}else{
db_query("UPDATE radioearn_api SET feedback='".$Feedback."',status='".$Status."' WHERE ip='".$IPE."' AND subid='".$SubID."' AND station='".$Station."' LIMIT 1");}
if ($capi[1] < time()){$bid = create_code(14);if ($capi[0] == 1){
db_query("UPDATE radioearn_api SET pts=pts+0.25,nextpayment='".$pfnmin."',feedback='".$Feedback."' WHERE ip='".$IPE."' AND subid='".$SubID."' AND station='".$Station."' LIMIT 1");$xche = $settings[1]/4;
db_query("UPDATE ".$db_prefix."_kontodaten SET kontostand=kontostand+".$xche." WHERE uid='".$SubID."' LIMIT 1");
buchungsliste ($bid,$xche,'Listen '.$Station.' ('.$IPE.')',$SubID);
refumsatz ($xche,$SubID);
}else{buchungsliste ($bid,'0',$Station.' not running or unsupported country ('.$IPE.')',$SubID);
db_query("UPDATE radioearn_api SET nextpayment='".$pfnmin."',feedback='".$Feedback."' WHERE ip='".$IPE."' AND subid='".$SubID."' AND station='".$Station."' LIMIT 1");}}}?>
