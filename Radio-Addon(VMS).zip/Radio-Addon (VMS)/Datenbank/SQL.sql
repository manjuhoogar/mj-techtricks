CREATE TABLE IF NOT EXISTS `radioearn_api` (
  `ip` varchar(50) NOT NULL,
  `subid` bigint(255) NOT NULL,
  `station` varchar(50) NOT NULL,
  `nextpayment` bigint(255) NOT NULL,
  `feedback` bigint(255) NOT NULL,
  `pts` double(30,2) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `radioearn_settings` (
  `api` varchar(100) NOT NULL,
  `uid` bigint(255) NOT NULL,
  `exchange` double(30,4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `radioearn_settings` (`api`, `uid`, `exchange`) VALUES
('https://radioearn.com/api/get.php?uid=', 0, 0.0000);

ALTER TABLE `radioearn_settings`
 ADD UNIQUE KEY `api` (`api`);
